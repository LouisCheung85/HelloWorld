mysql --version
